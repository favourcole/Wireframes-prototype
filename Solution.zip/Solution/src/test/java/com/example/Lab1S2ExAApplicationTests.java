package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1S2ExAApplicationTests {

	@Test
	void contextLoads() {
	}

}
