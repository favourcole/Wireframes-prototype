package com.example.controller;

import com.example.domain.MyUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@Controller
public class MyController {

	@GetMapping("/best/{what}")
	public String service(@PathVariable String what, Model model) {
		model.addAttribute("service", what);
		return "show";
	}

	@GetMapping("/greeting")
	public String greeting() {
		return "greeting";
	}
}
