package com.example;

import com.example.domain.MyRole;
import com.example.domain.MyUser;
import com.example.repository.MyUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class Lab1S2ExAApplication implements CommandLineRunner {

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private MyUserRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(Lab1S2ExAApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		MyUser user1 = new MyUser();
		user1.setName("guest");
		user1.setPassword(passwordEncoder.encode("password"));

		MyRole role1 = new MyRole();
		role1.setName("GUEST");

		user1.getRoles().add(role1);

		repository.save(user1);
	}
}
