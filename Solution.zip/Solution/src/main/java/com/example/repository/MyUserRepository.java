package com.example.repository;

import com.example.domain.MyUser;
import org.springframework.data.repository.CrudRepository;

public interface MyUserRepository extends CrudRepository<MyUser, String> {

    MyUser findByName(String name);
}
